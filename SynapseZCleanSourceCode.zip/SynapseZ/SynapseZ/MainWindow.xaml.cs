﻿using Microsoft.Win32;
using SynapseZAPI;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SynapseZ
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        SynapseZAPI.SynapseZAPI SynapseZAPI = new SynapseZAPI.SynapseZAPI();

        public MainWindow()
        {
            InitializeComponent();

            foreach (FileInfo File in new DirectoryInfo("./scripts").GetFiles("*.txt"))
            {
                Scripts.Items.Add(File.Name);
            }

            foreach (FileInfo File in new DirectoryInfo("./scripts").GetFiles("*.lua"))
            {
                Scripts.Items.Add(File.Name);
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            SynapseZAPI.Inject(Directory.GetCurrentDirectory());
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            SynapseZAPI.Execute(Directory.GetCurrentDirectory(), TextEditor.Text);
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            OpenFileDialog OpenFile = new OpenFileDialog();

            OpenFile.Title = "Synapse Z - Open File";
            OpenFile.Filter = "Txt Files (*.txt)|*.txt|Lua Files (*.lua)|*.lua|All Files (*.*)|*.*";

            if (OpenFile.ShowDialog() == true)
            {
                string Text = File.ReadAllText(OpenFile.FileName);

                TextEditor.Text = Text;
            }
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            SaveFileDialog SaveFile = new SaveFileDialog();

            SaveFile.Title = "Synapse Z - Open File";
            SaveFile.Filter = "Txt Files (*.txt)|*.txt|Lua Files (*.lua)|*.lua|All Files (*.*)|*.*";

            if (SaveFile.ShowDialog() == true)
            {
                string Text = TextEditor.Text;

                File.WriteAllText(SaveFile.FileName, Text);
            }
        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            OpenFileDialog ExecuteFile = new OpenFileDialog();

            ExecuteFile.Title = "Synapse Z - Execute File";
            ExecuteFile.Filter = "Txt Files (*.txt)|*.txt|Lua Files (*.lua)|*.lua|All Files (*.*)|*.*";

            if (ExecuteFile.ShowDialog() == true)
            {
                string Text = File.ReadAllText(ExecuteFile.FileName);

                SynapseZAPI.Execute(Directory.GetCurrentDirectory(), Text);
            }
        }

        private void Button_Click_5(object sender, RoutedEventArgs e)
        {
            base.Close();
        }

        private void Button_Click_6(object sender, RoutedEventArgs e)
        {
            WindowState = WindowState.Minimized;
        }

        private void Border_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
            {
                base.DragMove();
            }
        }
    }
}
