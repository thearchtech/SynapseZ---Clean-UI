﻿## About

Check out the [official documentation](http://avalonedit.net/documentation/) and the 
[samples and articles wiki page](https://github.com/icsharpcode/AvalonEdit/wiki/Samples-and-Articles)

Make sure to try the AvalonEdit sample application in the repository - its project has additional documentation included.

OSS projects using AvalonEdit are listed on the repository main page.